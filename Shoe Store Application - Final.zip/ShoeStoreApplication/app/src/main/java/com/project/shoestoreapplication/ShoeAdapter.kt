package com.project.shoestoreapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.project.shoestoreapplication.`interface`.OnShoeClickListener
import com.project.shoestoreapplication.model.Shoe
import java.text.DecimalFormat


class ShoeAdapter : RecyclerView.Adapter<ShoeAdapter.ViewHolder>() {
    /*
     Pendeklarasian variable dari interface yang akan kita isi item yang diklik disini terlebih
     dahulu, yang nantinya logic perpindahan ke bagian edit akan ditulis di MainActivity.
     */
    private lateinit var setOnShoeClickListener: OnShoeClickListener

    // Variable dibawah ini digunakan untuk menampung list item Sepatu.
    private val listShoe: ArrayList<Shoe> = ArrayList<Shoe>()

    /*
    Method buatan ini digunakan untuk mengisi variable ArrayList Sepate diatas. Kosongkan terlebih
    dahulu variable nya baru tambahkan semua list dari parameter kedalam variable diatas.
     */
    fun setListShoe(shoeList: ArrayList<Shoe>) {
        listShoe.clear()
        listShoe.addAll(shoeList)
        notifyDataSetChanged()
    }

    /*
    Method buatan ini mirip logikanya dengan method sebelumnya. Bedanya adalah method ini digunakan
    saat user mencari data lewat tampilan Search, maka tempel list hasil search tersebut ke dalam list.
     */
    fun filterList(filterlist: ArrayList<Shoe>) {
        listShoe.clear()
        listShoe.addAll(filterlist)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // Inflate layout per item dengan layout yang telah dibuat di direktori layout yaitu item_shoe.
        val view: View = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_shoe, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        // Set Data per item dengan method buatan pada Class ViewHolder dibawah.
        holder.setData(listShoe[position])

        /*
        Logic ketika itemView (tampilan 1 item penuh) diklik maka akan mengisinya dengan method
        dari interface buatan OnShoeClickListener.setOnShoeClickListener dengan parameter
        1 objek sepatu yang sedang kita klik.

        Nantinya objek sepatu ini dapat kita manfaatkan pada MainActivity ketika kita mengambil
        method setOnShoeClickListener dari adapter ini.
         */
        holder.itemView.setOnClickListener {
            setOnShoeClickListener.setOnShoeClickListener(
                listShoe[position]
            )
        }
    }

    override fun getItemViewType(position: Int): Int {
        return super.getItemViewType(position)
    }

    // Mengembalikan berapa jumlah item yang ditampilkan di RecyclerView. Jumlah akan fleksibel mengikuti size dari List Sepatu.
    override fun getItemCount() = listShoe.size

    /*
    Sebuah Class untuk menyambungkan dan/atau mengisi item-item view pada layout item_shoe sebelumnya.
     */
    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        // Pendeklarasian variable view yang ada pada item_shoe
        private var tvPegawaiName: TextView
        private var tvShoeName: TextView
        private var tvQuantity: TextView
        private var tvPrice: TextView
        private var tvTotalPrice: TextView

        init {
            // Ketika Class pertama kali dipanngin maka variable yang dideklarasika diatas akan langsung diinisialisasi dengan id yang sesuai pada layout item_shoe
            tvPegawaiName = itemView.findViewById(R.id.tv_pegawai_name)
            tvShoeName = itemView.findViewById(R.id.tv_shoe_name)
            tvQuantity = itemView.findViewById(R.id.tv_shoe_quantity)
            tvPrice = itemView.findViewById(R.id.tv_price)
            tvTotalPrice = itemView.findViewById(R.id.tv_total_price)
        }

        // Method buatan untuk mempermudah pengisian data per item RecyclerView. Jadi ketika pada bagian onBindViewHolder kita hanya perlu mengirimkan 1 objek sepatu saja.
        fun setData(shoe: Shoe) {
            tvPegawaiName.text = shoe.namaPegawai
            tvShoeName.text = shoe.namaSepatu
            tvQuantity.text = StringBuilder("Jumlah : ${shoe.jumlahSepatu}")
            tvPrice.text = StringBuilder("Harga : ${currencyFormat(shoe.harga)}")
            tvTotalPrice.text = StringBuilder("Total : ${currencyFormat(shoe.uangBayar)}")
        }
    }

    /*
    Method Publik buatan yang nantinya akan diakses pada MainActivity untuk berpindah ketika item di-klik.
     */
    fun setOnShoeClickListener(setOnShoeClickListener: OnShoeClickListener) {
        this.setOnShoeClickListener = setOnShoeClickListener
    }

    // Method buatan untuk mengubah format integer normal menjadi String dengan format desimal yang rapi.
    private fun currencyFormat(amount: Int): String {
        val formatter = DecimalFormat("###,###,##0.00")
        return formatter.format(amount)
    }
}
