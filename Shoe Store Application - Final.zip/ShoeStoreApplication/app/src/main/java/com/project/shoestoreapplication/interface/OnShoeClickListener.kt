package com.project.shoestoreapplication.`interface`

import com.project.shoestoreapplication.model.Shoe

interface OnShoeClickListener {
    // Method yang akan di-override oleh adapter akan item dari RecyclerView bisa diklik dan diedit.
    fun setOnShoeClickListener(shoe: Shoe)
}