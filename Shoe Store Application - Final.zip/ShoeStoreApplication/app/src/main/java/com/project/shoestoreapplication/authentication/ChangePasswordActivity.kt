package com.project.shoestoreapplication.authentication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.button.MaterialButton
import com.google.firebase.database.*
import com.project.shoestoreapplication.MainActivity
import com.project.shoestoreapplication.R
import com.project.shoestoreapplication.model.User

class ChangePasswordActivity : AppCompatActivity() {
    // Pendefinisian variable global privat dalam satu Class
    private lateinit var edEmail: EditText
    private lateinit var edPassword: EditText
    private lateinit var btnSaveChanges: MaterialButton
    private lateinit var progressBar: ProgressBar
    private lateinit var btnBack: TextView

    // Variable instance dari Firebase Realtime Database
    private val database = FirebaseDatabase.getInstance()

    /*
     Variable dimana dari instance sebelumnya lebih di-spesifikkan kita akan berurusan dengan
     struktur path mana, dimana sekarang kita spesifikkan pada path /users.
     */
    private val databaseReference = database.getReference("users")

    // Variable ArrayList User untuk menampung semua user agar bisa diproses nantinya.
    private val userList: ArrayList<User> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_change_password)

        // Inisialisasi variable View dengan menyambungkan id yang berada pada layout-nya.
        edEmail = findViewById(R.id.ed_email)
        edPassword = findViewById(R.id.ed_password)
        btnSaveChanges = findViewById(R.id.btn_save_changes)
        progressBar = findViewById(R.id.progressbar)
        btnBack = findViewById(R.id.tv_back)

        setListeners()
    }

    // Method buatan untuk menampung logika variable yang dapat di-Klik.
    private fun setListeners() {
        // Logika ketika tombol Save di-Klik.
        btnSaveChanges.setOnClickListener {

            /*
            Pengecekan validasi kolom dilakukan sebelum menjalankan logika untuk Login dengan
            memanggil method isValid()
             */
            if (isValid()) {
                // Memunculkan progressBar.
                showLoading(true)

                // Menampung isi text dari setiap kolom kedalam variable.
                val email = edEmail.text.toString()
                val password = edPassword.text.toString()

                // Variable sebagai penanda
                var flag = false
                var idUser = ""

                /*
                Pada penjelasan databaseReference sebelumnya dimana kita spesifikkan pada pengolahan
                data pada path /users. Disini kita memasang sebuah listener untuk mengambil semua
                data yang ada didalam path /users.
                 */
                databaseReference.addValueEventListener(object : ValueEventListener {

                    // dataSnapshot merupakan variable yang berisi semua data kita pada path /users.
                    override fun onDataChange(dataSnapshot: DataSnapshot) {
                        // Kosongkan list dari userList terlebih dahulu agar tidak saling tertumpuk
                        userList.clear()

                        /*
                        Dibawah ini perulangan untuk mengecek apakah terdapat user dengan email yang
                        sama dengan apa yang diinputkan sebelumnya. Kita ambil satu
                        persatu item pada dataSnapshot dan lakukan pengecekan manual dengan if.
                        Ketika cocok maka flag sebelumnya diubah menjadi true serta
                        masukkan key nama child user tersebut kedalam idUser, dan perulangan akan
                        di-Break.
                         */
                        for (dataSnap in dataSnapshot.children) {
                            val user: User? = dataSnap.getValue(User::class.java)
                            if (user?.email == email) {
                                flag = true
                                idUser = dataSnap.key!!
                                break
                            }
                        }

                        /*
                        Dibawah ini merupakan pengecekan flag. Ketika flag == true berarti email
                        ditemukan, maka update password dari email tersebut. Jika flag == false
                        maka email tidak ditemukan

                        Jangan lupa untuk removeEventListener agar tidak terjadi bug dimana listener
                        akan terpanggil berulang-ulang.
                         */
                        if (flag) {
                            // Arahkan ke nama child idUser yang sudah kita isi dengan key user yang benar
                            databaseReference.child(idUser).setValue(
                                User(
                                    email,
                                    password
                                )
                            ) { error: DatabaseError?, _: DatabaseReference? ->
                                databaseReference.removeEventListener(this)
                                if (error != null) {
                                    showLoading(false)
                                    showToast("Error: ${error.message}")
                                } else {
                                    showLoading(false)
                                    showToast("Password successfully changed! Please Login")
                                    finish()
                                }
                            }
                            databaseReference.removeEventListener(this)
                        } else {
                            showLoading(false)
                            showToast("Account isn't registered!")
                            databaseReference.removeEventListener(this)
                        }
                    }

                    // Method yang akan terpanggil ketika listener ter-Cancel.
                    override fun onCancelled(databaseError: DatabaseError) {
                        showLoading(false)
                        showToast("Error: ${databaseError.message}")
                    }
                })
            }
        }

        // Logic untuk kembali ke Login Activity
        btnBack.setOnClickListener {
            finish()
        }
    }

    /*
    Method pengecekan dimana ketika kolom email/password masih kosong/salah maka akan
    mengeluarkan Toast serta mengembalikan nilai false, dimana method ini dipanggil ketika
    mengeklik tombol Save.
    */
    private fun isValid(): Boolean {
        return if (!Patterns.EMAIL_ADDRESS.matcher(edEmail.text.toString()).matches()) {
            showToast("Email format is worng!")
            false
        } else if (edEmail.text.isEmpty()) {
            showToast("Email field can't be blank!")
            false
        } else if (edPassword.text.isEmpty()) {
            showToast("Password field can't be blank!")
            false
        } else {
            true
        }
    }

    /*
    Method buatan untuk memperlihatkan dan menyembunyikan tombol Save dan progressBar,
    dimana method ini akan dipanggil setelah validasi pengecekan isValid berhasil.
    */
    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            progressBar.visibility = View.VISIBLE
            btnSaveChanges.visibility = View.GONE
        } else {
            progressBar.visibility = View.GONE
            btnSaveChanges.visibility = View.VISIBLE
        }
    }

    /*
    Method buatan untuk membantu kita dalam memanggil Toast.
     */
    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}