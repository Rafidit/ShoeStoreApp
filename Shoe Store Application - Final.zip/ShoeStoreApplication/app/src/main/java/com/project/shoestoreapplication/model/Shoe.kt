package com.project.shoestoreapplication.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/*
Penggunaan data class dengan Parcelable untuk memudahkan proses pengiriman data, get maupun
set data pada class model.

Class ini digunakan hanya sebagai model untuk menampung data yang diolah ke Realtime
Database ataupun pada Adapter RecyclerView.
 */
@Parcelize
data class Shoe(
    var shoeKey: String = "",
    var namaPegawai: String = "",
    var namaSepatu: String = "",
    var jumlahSepatu: Int = 0,
    var harga: Int = 0,
    var uangBayar: Int = 0
) : Parcelable
