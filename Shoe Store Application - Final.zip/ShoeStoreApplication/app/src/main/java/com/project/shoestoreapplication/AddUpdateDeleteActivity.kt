package com.project.shoestoreapplication

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.project.shoestoreapplication.model.Shoe

class AddUpdateDeleteActivity : AppCompatActivity() {
    // Pendefinisian variable global privat dalam satu Class
    private lateinit var edPegawaiName: EditText
    private lateinit var edShoesName: EditText
    private lateinit var edQuantity: EditText
    private lateinit var edPrice: EditText
    private lateinit var edTotalPrice: EditText
    private lateinit var btnAction: MaterialButton
    private lateinit var btnDelete: MaterialButton
    private lateinit var progressBar: ProgressBar

    // Variable instance dari Firebase Realtime Database
    private val database = FirebaseDatabase.getInstance()

    /*
     Variable dimana dari instance sebelumnya lebih di-spesifikkan kita akan berurusan dengan
     struktur path mana, dimana sekarang kita spesifikkan pada path /shoes.
     */
    private val databaseReference = database.getReference("shoes")

    // Variable untuk menampung objek kiriman sepatu dari MainActivity ketika item sepatu RecyclerView diklik.
    private var shoe: Shoe? = null

    /*
    Variable logika yang nantinya digunakan untuk mengecek apakah Activity ini akan
    menjadi Add Activity atau UpdateDelete Activity.
     */
    private var isEdit = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_update_delete)

        // Inisialisasi variable View dengan menyambungkan id yang berada pada layout-nya.
        edPegawaiName = findViewById(R.id.ed_name_pegawai)
        edShoesName = findViewById(R.id.ed_shoes_name)
        edQuantity = findViewById(R.id.ed_shoes_quantity)
        edPrice = findViewById(R.id.ed_price)
        edTotalPrice = findViewById(R.id.ed_total_price)
        btnAction = findViewById(R.id.btn_action)
        btnDelete = findViewById(R.id.btn_delete)
        progressBar = findViewById(R.id.progressbar)

        /*
        Dibawah ini merupakan logika untuk menerima objek sepatu kiriman dari MainActivity.

        Jika variable shoe ternyata dapat menangkap sebuah objek sepatu (dimana kondisi ini
        didapatkan ketika item sepatu diklik) maka ubah isEdit menjadi true).

        Jika ternyata MainActivity tidak mengirimkan apa-apa atau shoes bernilai null
        (dimana kondisi ini didapatka ketika kita klik tombol Add dari MainActivity) maka
        buat isEdit menjadi false dan inisialisasi variable shoe dengan instance dari Shoe kosong
        agar tidak error.
         */
        shoe = intent.getParcelableExtra(SHOES_DETAIL)
        if (shoe != null) {
            isEdit = true
        } else {
            isEdit = false
            shoe = Shoe()
        }

        val actionBarTitle: String
        val btnTitle: String

        // Pemanggilan method buatan untuk menampilkan tombol delete ketika tampilan memang tampilan untuk edit (isEdit bernilai true)
        showDeleteButton(isEdit)

        /*
        Logika pengecekan isEdit.

        Ketika bernilai True maka ubah title Activity menjadi Edit Shoe, ubah text tombol menjadi
        Update, serta isi semua data pada bagian EditText dengan data sepatu yang sudah kita tangkap
        sebelumnya.

        Jika bernilai false maka ubah Title menjadi Add Shoe, serta ubah text tombol menjadi
        Insert, lalu biarkan EditText tetap kosong.
         */
        if (isEdit) {
            actionBarTitle = "Edit Shoe"
            btnTitle = "Update"

            edPegawaiName.setText(shoe!!.namaPegawai)
            edShoesName.setText(shoe!!.namaSepatu)
            edQuantity.setText("${shoe!!.jumlahSepatu}")
            edPrice.setText("${shoe!!.harga}")
            edTotalPrice.setText("${shoe!!.uangBayar}")

        } else {
            actionBarTitle = "Add Shoe"
            btnTitle = "Insert"
        }

        if (supportActionBar != null) {
            supportActionBar!!.title = actionBarTitle
        }
        btnAction.text = btnTitle

        setListeners()
    }

    // Method buatan untuk menampung logika variable yang dapat di-Klik.
    private fun setListeners() {

        /*
        Logika ketika tombol Delete diklik. maka remove/hapus child dari Realtime Databaser
        dengan nama child yaitu key yang kita simpan pada objek sepatu (variable shoeKey).

        Ketika berhasil menghapus maka setResult RESULT_OK agar setelah kembali ke MainActivity
        data data terefresh ulang dan tampilan bisa terupdate sesuai dengan data yang ada
        di Realtime Database.
         */
        btnDelete.setOnClickListener {
            databaseReference.child(shoe!!.shoeKey).removeValue().addOnSuccessListener {
                showToast("Successfully Delete Shoes Data!")
                val intent = Intent()
                setResult(RESULT_OK, intent)
                finish()
            }
        }

        /*
        Logika ketika tombol Action (Insert/Update) diklik.
         */
        btnAction.setOnClickListener {

            /*
            Pengecekan validasi kolom dilakukan sebelum menjalankan logika untuk Login dengan
            memanggil method isValid()
             */
            if (isValid()) {

                // Memunculkan progressBar.
                showLoading(true)

                // Menampung isi text dari setiap kolom kedalam variable.
                val namaPegawai = edPegawaiName.text.toString()
                val namaSepatu = edShoesName.text.toString()
                val jumlahSepatu = Integer.parseInt(edQuantity.text.toString())
                val hargaSepatu = Integer.parseInt(edPrice.text.toString())
                val uangBayar = Integer.parseInt(edTotalPrice.text.toString())

                // Memasukkan setiap data dari inputan kedalam objek Sepatu
                shoe?.namaPegawai = namaPegawai
                shoe?.namaSepatu = namaSepatu
                shoe?.jumlahSepatu = jumlahSepatu
                shoe?.harga = hargaSepatu
                shoe?.uangBayar = uangBayar

                /*
                Khusus untuk variable shoeKey dari Class Shoe dilakukan pengecekan tersendiri.

                Jika isEdit bernilai false (Tampilan merupakan Tampilan Add Data) maka kita harus push
                sebuah child terlebih dahulu ke Realtime Database dan dapatkan key nya. Setelah itu
                masukkan key tersebut kedalam variable shoeKey yang masih kosong.

                Jika isEdit bernilai true maka jangan apaapakan shoeKey, karena shoeKey sudah pernah
                terisi sebelumnya.
                 */
                if (!isEdit) {
                    val shoesKey = databaseReference.push().key
                    shoe?.shoeKey = shoesKey!!
                }

                /*
                Insert/Update data pada child dengan nama key yang telah tersimpan sebelumnya di shoeKey.
                 */
                databaseReference.child(shoe!!.shoeKey)
                    .setValue(shoe) { error: DatabaseError?, _: DatabaseReference? ->
                        /*
                        Jika error tidak null maka keluarkan informasi error tersebut,
                        jika tidak keluarkan informasi bahwa data berhasil di-Insert
                        ataupun di-Update sesuai dengan nilai isEdit.

                        Dan jika berhasil setResult menjadi RESULT_OK agar data bisa terupdate
                        kembali setelah kembali ke MainActivity.
                         */
                        if (error != null) {
                            showLoading(false)
                            showToast("Error: ${error.message}")
                        } else {
                            showLoading(false)
                            if (isEdit) {
                                showToast("Successfully Update Shoe Data!")
                            } else {
                                showToast("Successfully Add Shoe Data!")
                            }
                            val intent = Intent()
                            setResult(RESULT_OK, intent)
                            finish()
                        }
                    }

            }
        }
    }

    /*
    Method pengecekan dimana ketika kolom masih kosong maka akam mengeluarkan Toast serta
    mengembalikan nilai false, dimana method ini dipanggil ketika mengeklik tombol Login.
    */
    private fun isValid(): Boolean {
        return if (edPegawaiName.text.isEmpty()) {
            showToast("Nama Pegawai field can't be blank!")
            false
        } else if (edShoesName.text.isEmpty()) {
            showToast("Nama Sepatu field can't be blank!")
            false
        } else if (edQuantity.text.isEmpty()) {
            showToast("Jumlah field can't be blank!")
            false
        } else if (edPrice.text.isEmpty()) {
            showToast("Harga field can't be blank!")
            false
        } else if (edTotalPrice.text.isEmpty()) {
            showToast("Uang Bayar field can't be blank!")
            false
        } else {
            true
        }
    }

    /*
    Method buatan untuk memperlihatkan dan menyembunyikan tombol Action dan progressBar,
    dimana method ini akan dipanggil setelah validasi pengecekan isValid berhasil.
    */
    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            progressBar.visibility = View.VISIBLE
            btnAction.visibility = View.GONE
        } else {
            progressBar.visibility = View.GONE
            btnAction.visibility = View.VISIBLE
        }
    }

    /*
    Method buatan untuk memperlihatkan tombol Delete atau menyembunyikannya.
     */
    private fun showDeleteButton(isEdit: Boolean) {
        if (isEdit) {
            btnDelete.visibility = View.VISIBLE
        } else {
            btnDelete.visibility = View.GONE
        }
    }

    /*
    Method buatan untuk membantu kita dalam memanggil Toast.
     */
    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    /*
    Object pembantu yang berisi variable string constant untuk mengirimkan ataupun
    menerima object sepatu dari MainActivity.
     */
    companion object {
        const val SHOES_DETAIL: String = "shoes_detail"
    }
}