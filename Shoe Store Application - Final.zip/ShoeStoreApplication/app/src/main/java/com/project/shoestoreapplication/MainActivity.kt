package com.project.shoestoreapplication

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.widget.SearchView
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.project.shoestoreapplication.AddUpdateDeleteActivity.Companion.SHOES_DETAIL
import com.project.shoestoreapplication.`interface`.OnShoeClickListener
import com.project.shoestoreapplication.model.Shoe
import java.util.*
import kotlin.collections.ArrayList

class MainActivity : AppCompatActivity() {
    // Pendefinisian variable global privat dalam satu Class
    private lateinit var svShoe: SearchView
    private lateinit var rvShoes: RecyclerView
    private lateinit var btnAddShoe: FloatingActionButton

    // Variable instance dari Firebase Realtime Database
    private val database = FirebaseDatabase.getInstance()

    /*
     Variable dimana dari instance sebelumnya lebih di-spesifikkan kita akan berurusan dengan
     struktur path mana, dimana sekarang kita spesifikkan pada path /shoes.
     */
    private val databaseReference = database.getReference("shoes")

    // Variable ArrayList Shoe untuk menampung semua data sepatu kita.
    private val shoesList: ArrayList<Shoe> = ArrayList()

    // Variable untuk menampung Adapter ShoeAdapter untuk RecyclerView kita.
    private val shoeAdapter = ShoeAdapter()

    /*
    Variable pengganti startActivity() ketika ingin berpindah Activity dengan intent.
    variable ini dapat menerima masukan.

    Misal pada logika dibawah ketika kita klik tombol Add kita menggunakan variable ini
    untuk berpindah ke Halaman Add, jika data berhasil di-Add maka dari halaman Add sebelum
    kita kembalikan ke MainActivity kita setResult menjadi RESULT_OK terlebih dahulu.

    Sehingga ketika kembali pada MainActivity dilakukan pengecekan result seperti yang bisa
    dilihat dibawah ketika RESULT_OK maka langsung panggil method getShoesData() (Method untuk
    merefresh/mengambil ulang data dari firebase agar tampilan item dapat langsung ter-update)
     */
    val resultLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.data != null) {
            if (result.resultCode == RESULT_OK) {
                getShoesData()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inisialisasi variable View dengan menyambungkan id yang berada pada layout-nya.
        svShoe = findViewById(R.id.search_shoe)
        rvShoes = findViewById(R.id.rv_shoe)
        btnAddShoe = findViewById(R.id.btn_add_shoe)

        getShoesData()
        setListeners()
    }

    // Method buatan untuk menampung logika variable yang dapat di-Klik.
    private fun setListeners() {
        // Logika untuk berpindah ke Halaman AddUpdateActivity menggunakan variable resultLauncher.
        btnAddShoe.setOnClickListener {
            val iAdd = Intent(this, AddUpdateDeleteActivity::class.java)
            resultLauncher.launch(iAdd)
        }

        /*
        Membuat Listener yang dipasang pada SearchView agar setiap inputan dapat kita olah.
        dibawah ini terdapat 2 method yang di-override.
         */
        svShoe.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            // Method ini akan dijalankan ketika user telah selesai mengetik dan klik enter, kita tidak memanfaatkan method ini.
            override fun onQueryTextSubmit(p0: String?): Boolean {
                return false
            }

            /*
            Method ini dijalankan setiap user melakukan pengetikan di tampilan search. Kita memanfaatkan
            method ini agar kita bisa langsung memfilter item menggunakan method filter buatan dibawah
            agar dapat secara otomatis menampilkan data item sepatu yang ditulis.
             */
            override fun onQueryTextChange(msg: String): Boolean {
                filter(msg)
                return false
            }
        })
    }

    // Method buatan untuk mengambil data sepatu dari Realtime Database.
    private fun getShoesData() {

        /*
        Memasang Listener yang hanya berjalan sekali setelah data didapatkan untuk mendapatkan
        seluruh data sepatu kita.
         */
        databaseReference.addListenerForSingleValueEvent(object : ValueEventListener {

            // dataSnapshot merupakan variable yang berisi semua data kita pada path /shoes.
            override fun onDataChange(snapshot: DataSnapshot) {
                // Kosongkan list dari userList terlebih dahulu agar tidak saling tertumpuk
                shoesList.clear()

                /*
                Perulangan untuk menangkap data satu persatu dari snapShot dan memasukkannya kedalam
                variable shoe secara temporary. yang nantinya setiap satu perulangan akan ditambahkan
                objek sepatu tersebut kedalam list sepatu kita.
                 */
                for (dataSnap in snapshot.children) {
                    val shoe: Shoe? = dataSnap.getValue(Shoe::class.java)
                    shoesList.add(shoe!!)
                }

                /*
                Setelah list sepatu sudah terisi pada perulangan sebelumnya, maka panggil method buatan
                setRecyclerView untuk menampilkan data tersebut.
                 */
                setRecyclerView()
            }

            override fun onCancelled(error: DatabaseError) {
                showToast("Error : ${error.message}")
            }
        })
    }

    // Method buatan untuk mempermudah konfigurasi RecyclerView
    private fun setRecyclerView() {

        // Set data kedalam list pada Adapter RecyclerView menggunakan method buatan kita sebelumnya didalam ShoeAdapter
        shoeAdapter.setListShoe(shoesList)

        /*
        Logic yang telah dijelaskan sebelumnya pada ShoeAdapter yang berfungsi untuk berpindah
        halaman ketika salah satu item RecyclerView di-klik.

        Disini kita menambahkan Objek Sepatu yang telah kita inisialisasikan sebelumnya pada ShoeAdapter
        lalu kita kirimkan bersamaan dengan Intent.
         */
        shoeAdapter.setOnShoeClickListener(object : OnShoeClickListener {
            override fun setOnShoeClickListener(shoe: Shoe) {
                val iUpdateDelete = Intent(this@MainActivity, AddUpdateDeleteActivity::class.java)
                iUpdateDelete.putExtra(SHOES_DETAIL, shoe)
                resultLauncher.launch(iUpdateDelete)
            }
        })

        // Set adapter dan LayoutManager recyclerView agar data dapat tampil ke layar.
        rvShoes.adapter = shoeAdapter
        rvShoes.layoutManager = LinearLayoutManager(this)
    }

    /*
    Method buatan yang digunakan pada Listener SearchView, yang akan melakukan pengecekan
    mana data nama sepatu yang sesuai dengan apa yang kita inputkan pada tampilan search.

    Ketika data tidak kosong maka langsung set list sepatu di Adapter dengan list sepatu
    yang sudah kita filter disini.
     */
    private fun filter(text: String) {
        val filteredlist: ArrayList<Shoe> = ArrayList()

        for (item in shoesList) {
            if (item.namaSepatu.lowercase(Locale.getDefault())
                    .contains(text.lowercase(Locale.getDefault()))
            ) {
                filteredlist.add(item)
            }
        }
        if (filteredlist.isNotEmpty()) {
            shoeAdapter.filterList(filteredlist)
        }
    }

    /*
    Method buatan untuk membantu kita dalam memanggil Toast.
     */
    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}