package com.project.shoestoreapplication.authentication

import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.firebase.database.*
import com.project.shoestoreapplication.R
import com.project.shoestoreapplication.model.User

class RegisterActivity : AppCompatActivity() {
    // Pendefinisian variable global privat dalam satu Class
    private lateinit var edEmail: EditText
    private lateinit var edPassword: EditText
    private lateinit var btnRegister: MaterialButton
    private lateinit var progressBar: ProgressBar
    private lateinit var btnToLogin: TextView

    // Variable instance dari Firebase Realtime Database
    private val database = FirebaseDatabase.getInstance()

    /*
     Variable dimana dari instance sebelumnya lebih di-spesifikkan kita akan berurusan dengan
     struktur path mana, dimana sekarang kita spesifikkan pada path /users.
     */
    private val databaseReference = database.getReference("users")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        // Inisialisasi variable View dengan menyambungkan id yang berada pada layout-nya.
        edEmail = findViewById(R.id.ed_email)
        edPassword = findViewById(R.id.ed_password)
        btnRegister = findViewById(R.id.btn_register)
        progressBar = findViewById(R.id.progressbar)
        btnToLogin = findViewById(R.id.tv_to_login)

        setListeners()
    }

    // Method buatan untuk menampung logika variable yang dapat di-Klik.
    private fun setListeners() {
        // Logika ketika tombol Register di-Klik.
        btnRegister.setOnClickListener {

            /*
            Pengecekan validasi kolom dilakukan sebelum menjalankan logika untuk Login dengan
            memanggil method isValid()
             */
            if (isValid()) {
                // Memunculkan progressBar.
                showLoading(true)

                // Menampung isi text dari setiap kolom kedalam variable.
                val email = edEmail.text.toString()
                val password = edPassword.text.toString()

                // Membuat instance dari Class User untuk menampung data user yang nantinya akan dipush ke Realtime Database
                val user = User(email, password)

                /*
                Tambahkan secara otomatis data user dengan method push() maka nama child
                dari setiap akun akan auto digenerate menjadi sebuah key string acak.
                 */
                databaseReference.push().setValue(
                    user
                ) { error: DatabaseError?, _: DatabaseReference? ->
//                     Jika error tidak null maka keluarkan informasi error tersebut, jika tidak keluarkan informasi bahwa akun berhasil dibuat dan kembalikan ke Login.
                    if (error != null) {
                        showLoading(false)
                        showToast("Error: ${error.message}")
                    } else {
                        showLoading(false)
                        showToast("Account successfully registered! Please Login")
                        finish()
                    }
                }

            }
        }

        // Logic untuk berpindah ke Login kembali
        btnToLogin.setOnClickListener {
            finish()
        }
    }

    /*
    Method pengecekan dimana ketika kolom email/password masih kosong/salah maka akan
    mengeluarkan Toast serta mengembalikan nilai false, dimana method ini dipanggil ketika
    mengeklik tombol Login.
    */
    private fun isValid(): Boolean {
        return if (!Patterns.EMAIL_ADDRESS.matcher(edEmail.text.toString()).matches()) {
            showToast("Email format is worng!")
            false
        } else if (edEmail.text.isEmpty()) {
            showToast("Email field can't be blank!")
            false
        } else if (edPassword.text.isEmpty()) {
            showToast("Password field can't be blank!")
            false
        } else {
            true
        }
    }

    /*
    Method buatan untuk memperlihatkan dan menyembunyikan tombol Login dan progressBar,
    dimana method ini akan dipanggil ketika
    */
    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            progressBar.visibility = View.VISIBLE
            btnRegister.visibility = View.GONE
        } else {
            progressBar.visibility = View.GONE
            btnRegister.visibility = View.VISIBLE
        }
    }

    /*
    Method buatan untuk membantu kita dalam memanggil Toast.
     */
    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}